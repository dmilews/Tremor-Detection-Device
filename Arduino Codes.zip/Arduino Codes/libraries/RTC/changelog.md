
# Change Log

## v1.8.0

* Added Microchip's MCP7940
* Updated Examples
* Other BugFixes

## v1.7.0

* Added setDateTime(__TIMESTAMP__) Function
* Updated Examples